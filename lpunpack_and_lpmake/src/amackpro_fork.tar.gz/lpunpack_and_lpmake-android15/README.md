# lpunpack and lpmake

build :
./make.sh

source code from aosp
